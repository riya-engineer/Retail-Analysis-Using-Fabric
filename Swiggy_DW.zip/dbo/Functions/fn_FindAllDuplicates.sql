CREATE FUNCTION dbo.fn_FindAllDuplicates()
RETURNS TABLE
AS
RETURN
(
    /* =========================
       DUPLICATE DISH
       ========================= */
    SELECT
        'DIM_DISH' AS TableName,
        CAST(dish_id AS VARCHAR(100)) AS DuplicateID
    FROM
    (
        SELECT
            dish_id,
            ROW_NUMBER() OVER
            (
                PARTITION BY dish_id
                ORDER BY
                    CASE
                        WHEN dish_name IS NOT NULL THEN 1
                        ELSE 2
                    END,
                    category ASC
            ) AS RowNum
        FROM swiggy_project.dim_dish
    ) D
    WHERE RowNum > 1

    UNION ALL

    /* =========================
       DUPLICATE LOCATION
       ========================= */
    SELECT
        'DIM_LOCATION' AS TableName,
        CAST(location_id AS VARCHAR(100)) AS DuplicateID
    FROM
    (
        SELECT
            location_id,
            ROW_NUMBER() OVER
            (
                PARTITION BY location_id
                ORDER BY location_id
            ) AS RowNum
        FROM swiggy_project.dim_location
    ) L
    WHERE RowNum > 1

    UNION ALL

    /* =========================
       DUPLICATE RESTAURANT
       ========================= */
    SELECT
        'DIM_RESTAURANT' AS TableName,
        CAST(restaurant_id AS VARCHAR(100)) AS DuplicateID
    FROM
    (
        SELECT
            restaurant_id,
            ROW_NUMBER() OVER
            (
                PARTITION BY restaurant_id
                ORDER BY
                    CASE
                        WHEN restaurant_name IS NOT NULL THEN 1
                        ELSE 2
                    END,
                    restaurant_id ASC
            ) AS RowNum
        FROM swiggy_project.dim_restaurant
    ) R
    WHERE RowNum > 1

    UNION ALL

    /* =========================
       DUPLICATE FACT ORDERS
       ========================= */
    SELECT
        'FACT_ORDER' AS TableName,
        CAST(order_id AS VARCHAR(100)) AS DuplicateID
    FROM
    (
        SELECT
            order_id,
            ROW_NUMBER() OVER
            (
                PARTITION BY
                    order_id,
                    date_id,
                    location_id,
                    restaurant_id,
                    food_id,
                    price,
                    rating,
                    rating_count
                ORDER BY order_id
            ) AS RowNum
        FROM swiggy_project.fact_order
    ) F
    WHERE RowNum > 1
);

GO