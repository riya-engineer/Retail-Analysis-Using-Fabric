CREATE PROCEDURE dbo.RemoveDuplicatedate
AS
BEGIN

    WITH CTE_DeleteDuplicates AS
    (
        SELECT
            date_id,
            ROW_NUMBER() OVER
            (
                PARTITION BY date_id
                ORDER BY
                    CASE
                        WHEN order_date_new IS NOT NULL THEN 1
                        ELSE 2
                    END,
                    order_date ASC
            ) AS RowNum
        FROM swiggy_project.dim_date
    )

    DELETE FROM CTE_DeleteDuplicates
    WHERE RowNum > 1;

END;

GO