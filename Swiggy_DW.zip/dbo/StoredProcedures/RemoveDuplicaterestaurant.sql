CREATE PROCEDURE dbo.RemoveDuplicaterestaurant
AS
BEGIN
WITH CTE_DeleteDuplicates AS
(
    SELECT *,
           ROW_NUMBER() OVER
           (
               PARTITION BY restaurant_id
               ORDER BY restaurant_id
           ) AS RowNum
    FROM swiggy_project.dim_restaurant
)
DELETE FROM CTE_DeleteDuplicates
WHERE RowNum > 1;

END;

GO