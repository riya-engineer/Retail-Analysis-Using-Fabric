CREATE PROCEDURE dbo.RemoveDuplicatelocation
AS
BEGIN
WITH CTE_DeleteDuplicates AS
(
    SELECT *,
           ROW_NUMBER() OVER
           (
               PARTITION BY location_id
               ORDER BY location_id
           ) AS RowNum
    FROM swiggy_project.dim_location
)
DELETE FROM CTE_DeleteDuplicates
WHERE RowNum > 1;

END;

GO