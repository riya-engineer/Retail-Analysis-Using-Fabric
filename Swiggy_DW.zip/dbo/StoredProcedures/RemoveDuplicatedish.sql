CREATE PROCEDURE dbo.RemoveDuplicatedish
AS
BEGIN
WITH CTE_DeleteDuplicates AS
(
    SELECT *,
           ROW_NUMBER() OVER
           (
               PARTITION BY dish_id
               ORDER BY dish_id
           ) AS RowNum
    FROM swiggy_project.dim_dish
)
DELETE FROM CTE_DeleteDuplicates
WHERE RowNum > 1;

END;

GO