CREATE TABLE [swiggy_project].[dim_date] (
    [date_id]    VARCHAR (8000) NULL,
    [order_date] VARCHAR (8000) NULL
);


GO