CREATE TABLE [swiggy_project].[dim_restaurant] (
    [restaurant_id]   VARCHAR (8000) NULL,
    [restaurant_name] VARCHAR (8000) NULL
);


GO