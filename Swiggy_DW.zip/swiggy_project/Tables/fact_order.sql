CREATE TABLE [swiggy_project].[fact_order] (
    [order_id]      VARCHAR (8000) NULL,
    [date_id]       VARCHAR (8000) NULL,
    [location_id]   VARCHAR (8000) NULL,
    [restaurant_id] VARCHAR (8000) NULL,
    [food_id]       VARCHAR (8000) NULL,
    [price]         VARCHAR (8000) NULL,
    [rating]        VARCHAR (8000) NULL,
    [rating_count]  VARCHAR (8000) NULL
);


GO