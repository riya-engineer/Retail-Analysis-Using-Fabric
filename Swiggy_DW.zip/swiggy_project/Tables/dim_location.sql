CREATE TABLE [swiggy_project].[dim_location] (
    [location_id] VARCHAR (8000) NULL,
    [state]       VARCHAR (8000) NULL,
    [city]        VARCHAR (8000) NULL,
    [location]    VARCHAR (8000) NULL
);


GO