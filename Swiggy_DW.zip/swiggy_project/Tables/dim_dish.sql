CREATE TABLE [swiggy_project].[dim_dish] (
    [dish_id]   VARCHAR (8000) NULL,
    [category]  VARCHAR (8000) NULL,
    [dish_name] VARCHAR (8000) NULL
);


GO