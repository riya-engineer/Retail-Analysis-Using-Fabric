CREATE PROCEDURE swiggy_project.RemoveDuplicateorder
AS
BEGIN
WITH CTE_DeleteDuplicates AS
(
    SELECT *,
           ROW_NUMBER() OVER
           (
               PARTITION BY order_id
               ORDER BY order_id
           ) AS RowNum
    FROM swiggy_project.fact_order
)
DELETE FROM CTE_DeleteDuplicates
WHERE RowNum > 1;

END;

GO