CREATE SCHEMA [swiggy_project]
    AUTHORIZATION [dbo];


GO